import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
/**
 * Showroom demonstrates:
 * - composition (has lists of cars, workers, customers, sale records)
 * - serialization via FileManager.saveObject/loadObject
 * - searching & sorting using Collections and streams (STL-like)
 */
public class Showroom implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String DATA_FILE = "showroom_data.bin";

    // In Showroom.java, add these constants at the top after DATA_FILE:
public static final String WORKERS_FILE = "workers.txt";
public static final String CUSTOMERS_FILE = "customers.txt";
public static final String ADMINS_FILE = "admins.txt";
public static final String CARS_FILE = "cars.txt";

    // Composition: Showroom has-a lists
    private final List<Car> cars = new ArrayList<>();
    private final List<Worker> workers = new ArrayList<>();
    private final List<Customer> customers = new ArrayList<>();
    private final List<Admin> admins = new ArrayList<>();
    private final List<SaleRecord> sales = new ArrayList<>();
    private List<WorkerApplication> applications = new ArrayList<>();
    


  public Showroom() {
    // Initialize default admin
    initializeDefaultAdmin();
}

public List<WorkerApplication> getApplications() {
    return applications;
}


// Add these admin management methods to Showroom class:
public void addAdmin(Admin admin) {
    admins.add(admin);
    saveToDisk();
}

public Admin findAdminByUsername(String username) {
    for (Admin admin : admins) {
        if (admin.getUsername().equals(username)) {
            return admin;
        }
    }
    return null;
}

public List<Admin> getAdmins() {
    return admins;
}

public boolean removeAdmin(String username) {
    boolean removed = admins.removeIf(admin -> admin.getUsername().equals(username));
    if (removed) saveToDisk();
    return removed;
}

// Initialize with default admin if none exists
public void initializeDefaultAdmin() {
    if (admins.isEmpty()) {
        Admin defaultAdmin = new Admin(
            Admin.DEFAULT_ADMIN_USER, 
            Admin.DEFAULT_ADMIN_PASS, 
            "System Administrator",
            "Super"
        );
        admins.add(defaultAdmin);
    }
}

public void removeApplication(WorkerApplication app) {
    applications.remove(app);
    saveToDisk();
}

public void submitApplication(WorkerApplication app) {
    applications.add(app);
    saveToDisk();
}

public boolean approveApplication(int index) {
    if (index < 0 || index >= applications.size()) return false;

    WorkerApplication app = applications.remove(index);

    // FIXED: Correct parameter order for Worker constructor
    Worker newWorker = new Worker(
            app.getUsername(),      // username should come first
            app.getPassword(),      // password second
            app.getFullName()       // fullName third
    );

    workers.add(newWorker);
    saveToDisk();  // This will also save to text files
    return true;
}

// Add these methods to Showroom class (before or after saveToDisk method):
public void saveAllToTextFiles() {
    // Save workers with stats
    List<String> workerLines = new ArrayList<>();
    workerLines.add("Username,Password,FullName,SoldCount,AttendanceCount");
    for (Worker w : workers) {
        workerLines.add(String.format("%s,%s,%s,%d,%d", 
            w.getUsername(), w.getPassword(), w.getFullName(),
            w.getSoldCount(), w.getAttendanceCount()));
    }
    FileManager.writeLines(WORKERS_FILE, workerLines);
    
    // Save customers with spending
    List<String> customerLines = new ArrayList<>();
    customerLines.add("Username,Password,FullName,TotalSpent,OwnedCars");
    for (Customer c : customers) {
        String ownedCars = String.join(";", c.getOwnedCarIds());
        customerLines.add(String.format("%s,%s,%s,%d,%s",
            c.getUsername(), c.getPassword(), c.getFullName(),
            c.getTotalSpent(), ownedCars));
    }
    FileManager.writeLines(CUSTOMERS_FILE, customerLines);
    
    // Save admins (FIXED: save ALL admins, not just default)
    List<String> adminLines = new ArrayList<>();
    adminLines.add("Username,Password,FullName,AdminLevel");
    for (Admin admin : admins) {
        adminLines.add(admin.toString());
    }
    // Always ensure at least default admin exists
    if (admins.isEmpty()) {
        Admin defaultAdmin = new Admin(
            Admin.DEFAULT_ADMIN_USER, 
            Admin.DEFAULT_ADMIN_PASS, 
            "System Administrator",
            "Super"
        );
        adminLines.add(defaultAdmin.toString());
        admins.add(defaultAdmin);
    }
    FileManager.writeLines(ADMINS_FILE, adminLines);
    
    // Optional: Save cars to text file
    List<String> carLines = new ArrayList<>();
    carLines.add("ID,Name,Brand,Price,Quantity,Category");
    for (Car car : cars) {
        carLines.add(String.format("%s,%s,%s,%d,%d,%s",
            car.getId(), car.getName(), car.getBrand(),
            car.getPrice(), car.getQuantity(), car.getCategory()));
    }
    FileManager.writeLines(CARS_FILE, carLines);
    
    System.out.println("Text files updated: workers.txt, customers.txt, admins.txt, cars.txt");
}
public void loadFromTextFiles() {
    // Load workers
    List<String[]> workerData = FileManager.loadPersonsFromText(WORKERS_FILE);
    for (String[] data : workerData) {
        if (data.length >= 5 && !data[0].equals("Username")) {
            Worker w = new Worker(data[0], data[1], data[2]);
            try {
                w.setSoldCount(Integer.parseInt(data[3]));
                if (data.length >= 5) {
                    try {
                        w.setAttendanceCount(Integer.parseInt(data[4]));
                    } catch (NumberFormatException e) {
                        // Ignore if attendance not parseable
                    }
                }
            } catch (NumberFormatException e) {
                // Ignore if values not parseable
            }
            workers.add(w);
        }
    }
    
    // Load customers
    List<String[]> customerData = FileManager.loadPersonsFromText(CUSTOMERS_FILE);
    for (String[] data : customerData) {
        if (data.length >= 5 && !data[0].equals("Username")) {
            Customer c = new Customer(data[0], data[1], data[2]);
            try {
                c.addSpent(Integer.parseInt(data[3]));
            } catch (NumberFormatException e) {
                // Ignore if total spent not parseable
            }
            if (data.length >= 5 && !data[4].isEmpty()) {
                String[] carIds = data[4].split(";");
                for (String carId : carIds) {
                    if (!carId.isEmpty()) {
                        c.addOwnedCar(carId);
                    }
                }
            }
            customers.add(c);
        }
    }
    
    // Load admins
    List<String[]> adminData = FileManager.loadPersonsFromText(ADMINS_FILE);
    for (String[] data : adminData) {
        if (data.length >= 3 && !data[0].equals("Username")) {
            if (data.length >= 4) {
                // Has admin level
                Admin admin = new Admin(data[0], data[1], data[2], data[3]);
                admins.add(admin);
            } else {
                // No admin level specified
                Admin admin = new Admin(data[0], data[1], data[2]);
                admins.add(admin);
            }
        }
    }
    
    // Ensure at least one admin exists
    if (admins.isEmpty()) {
        Admin defaultAdmin = new Admin(
            Admin.DEFAULT_ADMIN_USER,
            Admin.DEFAULT_ADMIN_PASS,
            "System Administrator",
            "Super"
        );
        admins.add(defaultAdmin);
    }
    
    System.out.println("Loaded " + workers.size() + " workers, " + 
                      customers.size() + " customers, and " + 
                      admins.size() + " admins from text files");
}
// Add this method to Showroom class (at the end before the closing brace)
public void printTextFileContents() {
    System.out.println("\n=== WORKERS.TXT ===");
    List<String> workerLines = FileManager.readLines(WORKERS_FILE);
    for (String line : workerLines) {
        System.out.println(line);
    }
    
    System.out.println("\n=== CUSTOMERS.TXT ===");
    List<String> customerLines = FileManager.readLines(CUSTOMERS_FILE);
    for (String line : customerLines) {
        System.out.println(line);
    }
    
    System.out.println("\n=== ADMINS.TXT ===");
    List<String> adminLines = FileManager.readLines(ADMINS_FILE);
    for (String line : adminLines) {
        System.out.println(line);
    }
    
    System.out.println("\n=== CARS.TXT ===");
    List<String> carLines = FileManager.readLines(CARS_FILE);
    for (String line : carLines) {
        System.out.println(line);
    }
}
// Add this method to Showroom class
public void backupTextFiles(String backupFolder) {
    try {
        Files.createDirectories(Paths.get(backupFolder));
        
        // Copy each text file to backup folder
        java.nio.file.Files.copy(
            java.nio.file.Paths.get(WORKERS_FILE), 
            java.nio.file.Paths.get(backupFolder, "workers_backup.txt"), 
            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        java.nio.file.Files.copy(
            java.nio.file.Paths.get(CUSTOMERS_FILE), 
            java.nio.file.Paths.get(backupFolder, "customers_backup.txt"), 
            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        java.nio.file.Files.copy(
            java.nio.file.Paths.get(ADMINS_FILE), 
            java.nio.file.Paths.get(backupFolder, "admins_backup.txt"), 
            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        java.nio.file.Files.copy(
            java.nio.file.Paths.get(CARS_FILE), 
            java.nio.file.Paths.get(backupFolder, "cars_backup.txt"), 
            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        
        System.out.println("Backup created in folder: " + backupFolder);
    } catch (IOException e) {
        System.out.println("Backup failed: " + e.getMessage());
    }
}

    // Persistence: save/load showroom (stream I/O)
    public void saveToDisk() {
    // Save serialized object
    FileManager.saveObject(DATA_FILE, this);
    // Also save to text files
    saveAllToTextFiles();
}
    public boolean updateCar(String id, Integer newPrice, Integer newQty, String newCategory) {
    Car c = findCarById(id);
    if (c == null) return false;

    if (newPrice != null)
        c.setPrice(newPrice);

    if (newQty != null)
        c.setQuantity(newQty);

    if (newCategory != null)
        c.setCategory(newCategory);

    return true;
}


public static Showroom loadFromDisk() {
    Object o = FileManager.loadObject(DATA_FILE);
    if (o instanceof Showroom showroom) {
        // CRITICAL FIX: Handle case where admins field is null (old serialized object)
        // We need to use reflection to check and fix this
        
        try {
            // Check if admins is null using reflection
            java.lang.reflect.Field adminsField = Showroom.class.getDeclaredField("admins");
            adminsField.setAccessible(true);
            Object adminsValue = adminsField.get(showroom);
            
            if (adminsValue == null) {
                // The serialized object doesn't have admins field (old version)
                // Initialize it
                adminsField.set(showroom, new ArrayList<Admin>());
                System.out.println("INFO: Initialized admins list for old serialized object");
            }
        } catch (Exception e) {
            System.out.println("Warning: Could not check admins field: " + e.getMessage());
        }
        
        // Ensure default admin exists
        showroom.initializeDefaultAdmin();
        // Also ensure text files are up to date
        showroom.saveAllToTextFiles();
        return showroom;
    }
    
    // If no serialized file exists, create new showroom
    Showroom newShowroom = new Showroom();
    newShowroom.initializeDefaultAdmin();
    return newShowroom;
}

    // CRUD for cars
    public void addCar(Car c) { cars.add(c); saveToDisk(); }
    public boolean removeCarById(String id) {
        boolean removed = cars.removeIf(c -> c.getId().equals(id));
        if (removed) saveToDisk();
        return removed;
    }
    public Car findCarById(String id) {
        for (Car c : cars) if (c.getId().equals(id)) return c;
        return null;
    }
    public List<Car> getCars() { return cars; }

    // Workers
    public void addWorker(Worker w) { workers.add(w); saveToDisk(); }
    public Worker findWorkerByUsername(String u) {
        for (Worker w : workers) if (w.getUsername().equals(u)) return w;
        return null;
    }
    public List<Worker> getWorkers() { return workers; }

    // Customers
    public void addCustomer(Customer c) { customers.add(c); saveToDisk(); }
    public Customer findCustomerByUsername(String u) {
        for (Customer c : customers) if (c.getUsername().equals(u)) return c;
        return null;
    }
    public List<Customer> getCustomers() { return customers; }

    // Sales
    public void recordSale(SaleRecord sr) { sales.add(sr); saveToDisk(); }
    public List<SaleRecord> getSales() { return sales; }

    // Searching
    public List<Car> searchByName(String query) {
        String q = query.toLowerCase();
        return cars.stream().filter(c -> c.getName().toLowerCase().contains(q) || c.getBrand().toLowerCase().contains(q)).collect(Collectors.toList());
    }

    public List<Car> searchByPriceRange(int low, int high) {
        return cars.stream().filter(c -> c.getPrice() >= low && c.getPrice() <= high).collect(Collectors.toList());
    }

    // Sorting utilities (return copies)
    public List<Car> sortByPrice(boolean asc) {
        List<Car> copy = new ArrayList<>(cars);
        copy.sort(Comparator.comparingInt(Car::getPrice));
        if (!asc) Collections.reverse(copy);
        return copy;
    }

    public List<Car> sortByName() {
        List<Car> copy = new ArrayList<>(cars);
        copy.sort(Comparator.comparing(Car::getName, String.CASE_INSENSITIVE_ORDER));
        return copy;
    }

    // Worker leaderboard
    public List<Worker> workerLeaderboard() {
        List<Worker> copy = new ArrayList<>(workers);
        copy.sort((a,b) -> Integer.compare(b.getSoldCount(), a.getSoldCount()));
        return copy;
    }

    public void setApplications(List<WorkerApplication> applications) {
        this.applications = applications;
    }
}
