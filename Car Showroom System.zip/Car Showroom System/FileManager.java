import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * FileManager provides:
 * - text file read/write (for CSV-like quick exports)
 * - object serialization (save/load Showroom)
 */
public class FileManager {

    // Text file helpers
    public static List<String> readLines(String filename) {
        try {
            Path p = Paths.get(filename);
            if (!Files.exists(p)) Files.createFile(p);
            return Files.readAllLines(p);
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }


// Save a list of objects to a text file
public static <T> void saveListToText(String filename, List<T> items) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
        for (T item : items) {
            writer.write(item.toString());
            writer.newLine();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}

// Save a single Person object to text file (appends)
public static void savePersonToText(String filename, Person person) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
        writer.write(personToCsv(person));
        writer.newLine();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

// Convert Person to CSV format
private static String personToCsv(Person person) {
    return person.getUsername() + "," + 
           person.getPassword() + "," + 
           person.getFullName() + "," +
           person.getClass().getSimpleName();
}

// Load persons from text file
public static List<String[]> loadPersonsFromText(String filename) {
    List<String[]> persons = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
        String line;
        while ((line = reader.readLine()) != null) {
            if (!line.trim().isEmpty()) {
                persons.add(csv(line));
            }
        }
    } catch (IOException e) {
        // File doesn't exist yet - that's ok
    }
    return persons;
}

    public static void writeLines(String filename, List<String> lines) {
        try {
            Files.write(Paths.get(filename), lines);
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void appendLine(String filename, String line) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))) {
            bw.write(line);
            bw.newLine();
        } catch (IOException e) { e.printStackTrace(); }
    }

    // Object serialization helpers
    public static void saveObject(String filename, Object obj) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(obj);
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static Object loadObject(String filename) {
        Path p = Paths.get(filename);
        if (!Files.exists(p)) return null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) { e.printStackTrace(); return null; }
    }

    // Simple CSV parser helper (not robust to embedded commas)
    public static String[] csv(String line) {
        String[] parts = line.split(",");
        for (int i = 0; i < parts.length; i++) parts[i] = parts[i].trim();
        return parts;
    }
}
