import java.io.Serializable;

public class WorkerApplication implements Serializable {
    private final String name;
    private final String username;
    private final String password;
    private boolean approved;

    public WorkerApplication(String name, String username, String password) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.approved = false;
    }

    public String getFullName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void approve() {
        approved = true;
    }

    public boolean isApproved() {
        return approved;
    }

    // FIXED: Correct parameter order
    public Worker toWorker() {
        return new Worker(username, password, name);
    }

    @Override
    public String toString() {
        return name + " (" + username + ") - " +
                (approved ? "Approved" : "Pending");
    }
}