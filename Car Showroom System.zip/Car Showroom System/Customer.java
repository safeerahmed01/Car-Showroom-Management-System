import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Customer extends Person.
 * Composition: customer may own cars (ownedCars list).
 */
public class Customer extends Person {
    private static final long serialVersionUID = 1L;

    private int totalSpent;
    private List<String> ownedCarIds = new ArrayList<>();

    public Customer(String username, String password, String fullName) {
        super(username, password, fullName);
        this.totalSpent = 0;
    }

    public int getTotalSpent() { return totalSpent; }
    public void addSpent(int amount) { totalSpent += amount; }

    public List<String> getOwnedCarIds() { return ownedCarIds; }
    public void addOwnedCar(String carId) { ownedCarIds.add(carId); }
    public void removeOwnedCar(String carId) { ownedCarIds.remove(carId); }

    @Override
    public void menu(Scanner sc, Showroom showroom) {
        System.out.println("Customer menu for " + getFullName() + " (override example).");
    }
}
