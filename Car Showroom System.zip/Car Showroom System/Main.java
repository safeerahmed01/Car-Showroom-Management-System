// Main.java - COMPLETE FIXED VERSION
import java.util.*;

/**
 * Main launcher and CLI menu for the Car Showroom project.
 * Integrates with Showroom and FileManager from Part 1.
 */
public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static Showroom showroom;

    public static void main(String[] args) {
    // load existing showroom or create a new one
    showroom = Showroom.loadFromDisk();
    if (showroom == null) {
        showroom = new Showroom();
        // seed some sample data if empty
        seedSampleData();
        showroom.saveToDisk();
    }
    
    // Ensure default admin exists
    showroom.initializeDefaultAdmin();

    System.out.println("=== Welcome to Car Showroom System ===");

    mainLoop();
}
    
private static void seedSampleData() {
    // Initialize default admin if none exists
    showroom.initializeDefaultAdmin();
    
    // only add if no cars/workers/customers present
    if (showroom.getCars().isEmpty()) {
        showroom.addCar(new Car("Civic", "Honda", 6500000, 3, "Sedan"));
        showroom.addCar(new Car("Corolla", "Toyota", 5500000, 2, "Sedan"));
        showroom.addCar(new Car("Model 3", "Tesla", 20000000, 1, "Electric"));
    }
    if (showroom.getWorkers().isEmpty()) {
        Worker w1 = new Worker("ali", "w123", "Ali");
        Worker w2 = new Worker("basit", "w123", "Basit");
        showroom.addWorker(w1);
        showroom.addWorker(w2);
    }
    if (showroom.getCustomers().isEmpty()) {
        Customer c1 = new Customer("saad", "c123", "Saad");
        showroom.addCustomer(c1);
    }
    // Force save to create text files
    showroom.saveAllToTextFiles();
}
    private static void mainLoop() {
        while (true) {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Admin Login");
            System.out.println("2. Worker Login");
            System.out.println("3. Apply for Job (Worker)");
            System.out.println("4. Customer (Login / Signup)");
            System.out.println("5. Browse / Search Cars (Guest)");
            System.out.println("6. Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1" -> adminFlow();
                case "2" -> workerFlow();
                case "3" -> applyForJob(); 
                case "4" -> customerFlow();
                case "5" -> guestBrowse();
                case "6" -> {
                    showroom.saveToDisk();
                    System.out.println("Saved. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid input, try again.");
            }
        }
    }

    private static void applyForJob() {
        System.out.println("\n--- WORKER JOB APPLICATION ---");

        System.out.print("Full Name: ");
        String name = sc.nextLine();

        System.out.print("Username: ");
        String username = sc.nextLine();

        System.out.print("Password: ");
        String password = sc.nextLine();

        WorkerApplication app = new WorkerApplication(name, username, password);
        showroom.submitApplication(app);

        System.out.println("\nApplication submitted successfully!");
        System.out.println("Wait for admin approval.");
    }

    // ---------------- Admin flow ----------------

private static void adminFlow() {
    System.out.print("Admin username: ");
    String u = sc.nextLine().trim();
    System.out.print("Admin password: ");
    String p = sc.nextLine().trim();

    // Check against all admins, not just default
    Admin loggedInAdmin = showroom.findAdminByUsername(u);
    if (loggedInAdmin == null || !loggedInAdmin.getPassword().equals(p)) {
        System.out.println("Invalid admin credentials.");
        return;
    }

    System.out.println("Welcome " + loggedInAdmin.getFullName() + " (Level: " + loggedInAdmin.getAdminLevel() + ")");
    
    while (true) {
        System.out.println("\n--- ADMIN MENU ---");
        System.out.println("1. Add Car");
        System.out.println("2. Update Car (price/qty/category)");
        System.out.println("3. Remove Car");
        System.out.println("4. View All Cars");
        System.out.println("5. Worker Leaderboard");
        System.out.println("6. Export Sales Text (append to sales.txt)");
        System.out.println("7. Approve Worker Applications");
        System.out.println("8. View User Text Files");
        System.out.println("9. Export Users to CSV");
        
        // Add admin management options (only for Super admins)
        if (loggedInAdmin.getAdminLevel().equals("Super")) {
            System.out.println("10. Manage Admins (Add/Remove)");
            System.out.println("11. Create New Admin Account");
            System.out.println("12. Back to Main Menu");
        } else {
            System.out.println("10. Back to Main Menu");
        }
        
        System.out.print("Choose: ");
        String ch = sc.nextLine().trim();

        switch (ch) {
            case "1" -> addCarAsAdmin();
            case "2" -> updateCarAsAdmin();
            case "3" -> removeCarAsAdmin();
            case "4" -> listCars(showroom.getCars());
            case "5" -> showWorkerLeaderboard();
            case "6" -> exportSalesText();
            case "7" -> approveApplications();
            case "8" -> viewUserTextFiles();
            case "9" -> {
                showroom.saveAllToTextFiles();
                System.out.println("Users exported to CSV text files.");
            }
            case "10" -> {
                if (loggedInAdmin.getAdminLevel().equals("Super")) {
                    manageAdmins();
                } else {
                    showroom.saveToDisk();
                    return;
                }
            }
            case "11" -> {
                if (loggedInAdmin.getAdminLevel().equals("Super")) {
                    createNewAdmin();
                } else {
                    System.out.println("Invalid option.");
                }
            }
            case "12" -> {
                if (loggedInAdmin.getAdminLevel().equals("Super")) {
                    showroom.saveToDisk();
                    return;
                } else {
                    System.out.println("Invalid option.");
                }
            }
            default -> System.out.println("Invalid option.");
        }
    }
}
private static void viewUserTextFiles() {
    System.out.println("\n--- USER TEXT FILES ---");
    System.out.println("1. View All Text Files");
    System.out.println("2. View Workers (workers.txt)");
    System.out.println("3. View Customers (customers.txt)");
    System.out.println("4. View Admins (admins.txt)");
    System.out.println("5. View Cars (cars.txt)");
    System.out.println("6. View Sales (sales.txt)");
    System.out.println("7. View Worker Applications");
    System.out.println("8. Back to Admin Menu");
    System.out.print("Choose: ");
    String opt = sc.nextLine().trim();
    
    switch (opt) {
        case "1" -> viewAllTextFiles();
        case "2" -> {
            System.out.println("\n--- WORKERS.TXT ---");
            List<String> workers = FileManager.readLines(Showroom.WORKERS_FILE);
            if (workers.isEmpty()) {
                System.out.println("File is empty or doesn't exist.");
            } else {
                workers.forEach(System.out::println);
            }
        }
        case "3" -> {
            System.out.println("\n--- CUSTOMERS.TXT ---");
            List<String> customers = FileManager.readLines(Showroom.CUSTOMERS_FILE);
            if (customers.isEmpty()) {
                System.out.println("File is empty or doesn't exist.");
            } else {
                customers.forEach(System.out::println);
            }
        }
        case "4" -> {
            System.out.println("\n--- ADMINS.TXT ---");
            List<String> admins = FileManager.readLines(Showroom.ADMINS_FILE);
            if (admins.isEmpty()) {
                System.out.println("File is empty or doesn't exist.");
            } else {
                admins.forEach(System.out::println);
            }
        }
        case "5" -> {
            System.out.println("\n--- CARS.TXT ---");
            List<String> cars = FileManager.readLines(Showroom.CARS_FILE);
            if (cars.isEmpty()) {
                System.out.println("File is empty or doesn't exist.");
            } else {
                cars.forEach(System.out::println);
            }
        }
        case "6" -> {
            System.out.println("\n--- SALES.TXT ---");
            List<String> sales = FileManager.readLines("sales.txt");
            if (sales.isEmpty()) {
                System.out.println("File is empty or doesn't exist.");
            } else {
                sales.forEach(System.out::println);
            }
        }
        case "7" -> {
            System.out.println("\n--- WORKER APPLICATIONS ---");
            List<WorkerApplication> apps = showroom.getApplications();
            if (apps == null || apps.isEmpty()) {
                System.out.println("No pending applications.");
            } else {
                for (int i = 0; i < apps.size(); i++) {
                    WorkerApplication app = apps.get(i);
                    System.out.println((i + 1) + ". " + app.getFullName() + 
                                     " | Username: " + app.getUsername() + 
                                     " | Status: " + (app.isApproved() ? "Approved" : "Pending"));
                }
            }
        }
        case "8" -> { return; }
        default -> System.out.println("Invalid choice.");
    }
}

private static void viewAllTextFiles() {
    System.out.println("\n=== ALL TEXT FILES ================================");
    
    System.out.println("\n1. WORKERS.TXT:");
    System.out.println("--------------------------------------------------");
    List<String> workers = FileManager.readLines(Showroom.WORKERS_FILE);
    if (workers.isEmpty()) {
        System.out.println("   (File is empty or doesn't exist)");
    } else {
        workers.forEach(line -> System.out.println("   " + line));
    }
    
    System.out.println("\n2. CUSTOMERS.TXT:");
    System.out.println("--------------------------------------------------");
    List<String> customers = FileManager.readLines(Showroom.CUSTOMERS_FILE);
    if (customers.isEmpty()) {
        System.out.println("   (File is empty or doesn't exist)");
    } else {
        customers.forEach(line -> System.out.println("   " + line));
    }
    
    System.out.println("\n3. ADMINS.TXT:");
    System.out.println("--------------------------------------------------");
    List<String> admins = FileManager.readLines(Showroom.ADMINS_FILE);
    if (admins.isEmpty()) {
        System.out.println("   (File is empty or doesn't exist)");
    } else {
        admins.forEach(line -> System.out.println("   " + line));
    }
    
    System.out.println("\n4. CARS.TXT:");
    System.out.println("--------------------------------------------------");
    List<String> cars = FileManager.readLines(Showroom.CARS_FILE);
    if (cars.isEmpty()) {
        System.out.println("   (File is empty or doesn't exist)");
    } else {
        cars.forEach(line -> System.out.println("   " + line));
    }
    
    System.out.println("\n5. SALES.TXT:");
    System.out.println("--------------------------------------------------");
    List<String> sales = FileManager.readLines("sales.txt");
    if (sales.isEmpty()) {
        System.out.println("   (File is empty or doesn't exist)");
    } else {
        sales.forEach(line -> System.out.println("   " + line));
    }
    
    System.out.println("\n6. WORKER APPLICATIONS:");
    System.out.println("--------------------------------------------------");
    List<WorkerApplication> apps = showroom.getApplications();
    if (apps == null || apps.isEmpty()) {
        System.out.println("   (No pending applications)");
    } else {
        for (int i = 0; i < apps.size(); i++) {
            WorkerApplication app = apps.get(i);
            System.out.println("   " + (i + 1) + ". " + app.getFullName() + 
                             " | Username: " + app.getUsername());
        }
    }
    
    System.out.println("\n==================================================");
    
    System.out.print("\nPress Enter to continue...");
    sc.nextLine();
}

private static void manageAdmins() {
    while (true) {
        System.out.println("\n--- ADMIN MANAGEMENT ---");
        System.out.println("1. View All Admins");
        System.out.println("2. Add New Admin");
        System.out.println("3. Remove Admin");
        System.out.println("4. Back to Admin Menu");
        System.out.print("Choose: ");
        String choice = sc.nextLine().trim();
        
        switch (choice) {
            case "1" -> {
                System.out.println("\n--- ALL ADMINS ---");
                List<Admin> admins = showroom.getAdmins();
                if (admins.isEmpty()) {
                    System.out.println("No admins found.");
                } else {
                    for (int i = 0; i < admins.size(); i++) {
                        Admin admin = admins.get(i);
                        System.out.println((i+1) + ". " + admin.getUsername() + 
                                         " - " + admin.getFullName() + 
                                         " (Level: " + admin.getAdminLevel() + ")");
                    }
                }
            }
            case "2" -> createNewAdmin();
            case "3" -> removeAdmin();
            case "4" -> { return; }
            default -> System.out.println("Invalid choice.");
        }
    }
}

private static void createNewAdmin() {
    System.out.println("\n--- CREATE NEW ADMIN ---");
    
    System.out.print("Username: ");
    String username = sc.nextLine().trim();
    
    // Check if username already exists
    if (showroom.findAdminByUsername(username) != null) {
        System.out.println("Username already exists!");
        return;
    }
    
    System.out.print("Password: ");
    String password = sc.nextLine().trim();
    
    System.out.print("Full Name: ");
    String fullName = sc.nextLine().trim();
    
    System.out.print("Admin Level (Super/Manager/Basic): ");
    String level = sc.nextLine().trim();
    
    if (!level.equals("Super") && !level.equals("Manager") && !level.equals("Basic")) {
        System.out.println("Invalid level. Setting to Basic.");
        level = "Basic";
    }
    
    Admin newAdmin = new Admin(username, password, fullName, level);
    showroom.addAdmin(newAdmin);
    
    System.out.println("Admin account created successfully!");
}

private static void removeAdmin() {
    System.out.println("\n--- REMOVE ADMIN ---");
    
    List<Admin> admins = showroom.getAdmins();
    if (admins.size() <= 1) {
        System.out.println("Cannot remove the only admin!");
        return;
    }
    
    System.out.println("Current Admins:");
    for (int i = 0; i < admins.size(); i++) {
        Admin admin = admins.get(i);
        System.out.println((i+1) + ". " + admin.getUsername() + " - " + admin.getFullName());
    }
    
    System.out.print("Enter admin number to remove (or 0 to cancel): ");
    String input = sc.nextLine().trim();
    
    try {
        int choice = Integer.parseInt(input);
        if (choice == 0) return;
        
        if (choice > 0 && choice <= admins.size()) {
            Admin toRemove = admins.get(choice - 1);
            
            // Prevent removing the default super admin
            if (toRemove.getUsername().equals(Admin.DEFAULT_ADMIN_USER)) {
                System.out.println("Cannot remove the default super admin!");
                return;
            }
            
            System.out.print("Are you sure you want to remove admin '" + toRemove.getUsername() + "'? (yes/no): ");
            String confirm = sc.nextLine().trim().toLowerCase();
            
            if (confirm.equals("yes")) {
                boolean removed = showroom.removeAdmin(toRemove.getUsername());
                if (removed) {
                    System.out.println("Admin removed successfully.");
                } else {
                    System.out.println("Failed to remove admin.");
                }
            }
        } else {
            System.out.println("Invalid choice.");
        }
    } catch (NumberFormatException e) {
        System.out.println("Invalid input.");
    }
}

    static void approveApplications() {
        var apps = showroom.getApplications();

        if (apps == null || apps.isEmpty()) {
            System.out.println("No pending applications.");
            return;
        }

        System.out.println("\n--- WORKER APPLICATIONS ---");
        for (int i = 0; i < apps.size(); i++) {
            var a = apps.get(i);
            System.out.println((i + 1) + ". " + a.getFullName()
                    + " | Username: " + a.getUsername());
        }

        System.out.print("Select application number (0 to cancel): ");
        String input = sc.nextLine();

        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input.");
            return;
        }

        if (choice == 0) return;
        if (choice < 1 || choice > apps.size()) {
            System.out.println("Invalid choice.");
            return;
        }

        var selected = apps.get(choice - 1);

        System.out.print("Approve (A) or Reject (R)? ");
        String decision = sc.nextLine().toUpperCase();

        switch (decision) {
            case "A" -> {
                // FIXED: Create Worker with CORRECT parameter order
                // Worker constructor expects: (username, password, fullName)
                Worker w = new Worker(
                        selected.getUsername(),    // username - CORRECT
                        selected.getPassword(),    // password - CORRECT  
                        selected.getFullName()     // fullName - CORRECT
                );
                showroom.addWorker(w);                // adds worker
                showroom.removeApplication(selected); // removes application
                showroom.saveToDisk();
                System.out.println("Application approved. Worker '" + selected.getUsername() + "' can now login.");
            }
            case "R" -> {
                showroom.removeApplication(selected);
                showroom.saveToDisk();
                System.out.println("Application rejected.");
            }
            default -> System.out.println("Cancelled.");
        }
    }

    private static void addCarAsAdmin() {
        System.out.print("Car name: "); String name = sc.nextLine().trim();
        System.out.print("Brand: "); String brand = sc.nextLine().trim();
        System.out.print("Price (integer): ");
        int price = readIntOrZero();
        System.out.print("Quantity (integer): ");
        int qty = readIntOrZero();
        System.out.print("Category: "); String cat = sc.nextLine().trim();
        Car c = new Car(name, brand, price, qty, cat);
        showroom.addCar(c);
        System.out.println("Added car: " + c);
    }

    private static void updateCarAsAdmin() {
        System.out.print("Enter Car ID to update: "); String id = sc.nextLine().trim();
        Car c = showroom.findCarById(id);
        if (c == null) { System.out.println("Car not found."); return; }
        System.out.println("Selected: " + c);
        System.out.print("New price (enter to skip): "); String np = sc.nextLine().trim();
        System.out.print("New quantity (enter to skip): "); String nq = sc.nextLine().trim();
        System.out.print("New category (enter to skip): "); String nc = sc.nextLine().trim();
        Integer price = np.isEmpty() ? null : Integer.valueOf(np);
        Integer qty = nq.isEmpty() ? null : Integer.valueOf(nq);
        String cat = nc.isEmpty() ? null : nc;
        boolean ok = showroom.updateCar(id, price, qty, cat);
        System.out.println(ok ? "Updated." : "Update failed.");
    }

    private static void removeCarAsAdmin() {
        System.out.print("Car ID to remove: "); String id = sc.nextLine().trim();
        boolean ok = showroom.removeCarById(id);
        System.out.println(ok ? "Removed." : "Not found.");
    }

    private static void showWorkerLeaderboard() {
        System.out.println("---- WORKER LEADERBOARD ----");
        List<Worker> lb = showroom.workerLeaderboard();
        for (Worker w : lb) {
            System.out.println(w.getUsername() + " | Sold: " + w.getSoldCount() + " | Attendance: " + w.getAttendanceCount());
        }
    }

    private static void exportSalesText() {
        List<SaleRecord> sales = showroom.getSales();
        if (sales.isEmpty()) {
            System.out.println("No sales yet.");
            return;
        }
        for (SaleRecord sr : sales) {
            FileManager.appendLine("sales.txt", sr.toString());
        }
        System.out.println("Appended " + sales.size() + " sales to sales.txt");
    }

    // ---------------- Worker flow ----------------
    private static void workerFlow() {
        System.out.print("Worker username: "); String username = sc.nextLine().trim();
        System.out.print("Password: "); String password = sc.nextLine().trim();
        
        Worker w = showroom.findWorkerByUsername(username);
        if (w == null || !w.getPassword().equals(password)) {
            System.out.println("Invalid worker credentials.");
            return;
        }
        
        // mark attendance
        w.incrementAttendance();
        showroom.saveToDisk();
        System.out.println("Welcome " + w.getFullName() + ". Attendance recorded.");

        while (true) {
            System.out.println("\n--- WORKER MENU ---");
            System.out.println("1. Sell Car");
            System.out.println("2. View Cars");
            System.out.println("3. My Stats");
            System.out.println("4. Back to Main Menu");
            System.out.print("Choose: ");
            String ch = sc.nextLine().trim();
            switch (ch) {
                case "1" -> workerSellFlow(w);
                case "2" -> listCars(showroom.getCars());
                case "3" -> {
                    System.out.println("You: " + w.getUsername() + " | Sold: " + w.getSoldCount() + " | Attendance: " + w.getAttendanceCount());
                }
                case "4" -> { showroom.saveToDisk(); return; }
                default -> System.out.println("Invalid");
            }
        }
    }

    private static void workerSellFlow(Worker w) {
        listCars(showroom.getCars());
        System.out.print("Enter Car ID to sell: "); String cid = sc.nextLine().trim();
        Car car = showroom.findCarById(cid);
        if (car == null) { System.out.println("Car not found."); return; }
        if (!car.inStock()) { System.out.println("Car out of stock."); return; }
        System.out.print("Customer username (or guest name): "); String cust = sc.nextLine().trim();
        // perform sale
        boolean sold = car.sellOne();
        if (!sold) { System.out.println("Failed to sell (out of stock)."); return; }

        // record sale
        String saleId = UUID.randomUUID().toString().substring(0,8);
        SaleRecord sr = new SaleRecord(saleId, car.getId(), car.getName(), cust, w.getUsername(), car.getPrice());
        showroom.recordSale(sr);
        // update worker record
        w.recordSale(sr);
        // update customer
        Customer cu = showroom.findCustomerByUsername(cust);
        if (cu != null) {
            cu.addSpent(car.getPrice());
            cu.addOwnedCar(car.getId());
        }
        // write human-readable invoice to sales.txt
        FileManager.appendLine("sales.txt", sr.toString());
        showroom.saveToDisk();
        System.out.println("Sale recorded. Invoice appended to sales.txt");
    }

    // ---------------- Customer flow ----------------
    private static void customerFlow() {
        System.out.println("\n1. Signup");
        System.out.println("2. Login");
        System.out.print("Choose: ");
        String choice = sc.nextLine().trim();
        switch (choice) {
            case "1" -> {
                System.out.print("Choose username: "); String u = sc.nextLine().trim();
                if (showroom.findCustomerByUsername(u) != null) { System.out.println("Username exists."); return; }
                System.out.print("Password: "); String p = sc.nextLine().trim();
                System.out.print("Full name: "); String fn = sc.nextLine().trim();
                Customer c = new Customer(u, p, fn);
                showroom.addCustomer(c);
                System.out.println("Registered. Please login.");
            }

            case "2" -> {
                System.out.print("Username: ");
                String u = sc.nextLine().trim();
                System.out.print("Password: ");
                String p = sc.nextLine().trim();
                Customer c = showroom.findCustomerByUsername(u);
                if (c == null || !c.getPassword().equals(p)) { System.out.println("Invalid credentials."); return; }
                System.out.println("Welcome " + c.getFullName());
                // customer menu
                while (true) {
                    System.out.println("\n--- CUSTOMER MENU ---");
                    System.out.println("1. Buy Car");
                    System.out.println("2. Sell Your Car (Sell-back)");
                    System.out.println("3. View Purchase History (sales.txt)");
                    System.out.println("4. View My Account");
                    System.out.println("5. Search / Filter Cars");
                    System.out.println("6. Back to Main Menu");
                    System.out.print("Choose: ");
                    String opt = sc.nextLine().trim();
                    switch (opt) {
                        case "1" -> customerBuyFlow(c);
                        case "2" -> customerSellBackFlow(c);
                        case "3" -> viewCustomerSales(c);
                        case "4" -> System.out.println("Username: " + c.getUsername() + " | Name: " + c.getFullName() + " | Total Spent: Rs." + c.getTotalSpent());
                        case "5" -> searchFilterFlow();
                        case "6" -> { showroom.saveToDisk(); return; }
                        default -> System.out.println("Invalid");
                    }
                }
            }
            default -> System.out.println("Invalid choice.");
        }
    }

    private static void customerBuyFlow(Customer c) {
        listCars(showroom.getCars());
        System.out.print("Enter Car ID to buy: "); String cid = sc.nextLine().trim();
        Car car = showroom.findCarById(cid);
        if (car == null) { System.out.println("Car not found."); return; }
        if (!car.inStock()) { System.out.println("Car out of stock."); return; }
        boolean sold = car.sellOne();
        if (!sold) { System.out.println("Purchase failed."); return; }

        String saleId = UUID.randomUUID().toString().substring(0,8);
        SaleRecord sr = new SaleRecord(saleId, car.getId(), car.getName(), c.getUsername(), "N/A", car.getPrice());
        showroom.recordSale(sr);
        c.addSpent(car.getPrice());
        c.addOwnedCar(car.getId());
        FileManager.appendLine("sales.txt", sr.toString());
        showroom.saveToDisk();
        System.out.println("Purchase successful. Invoice appended to sales.txt");
    }

    private static void customerSellBackFlow(Customer c) {
        System.out.println("Your owned cars: " + c.getOwnedCarIds());
        System.out.print("Enter Car ID to sell back: "); String cid = sc.nextLine().trim();
        Car car = showroom.findCarById(cid);
        if (car == null) { System.out.println("Car not found in showroom (but will still accept)."); }
        System.out.print("Amount you will accept (integer): "); int amt = readIntOrZero();
        // increase showroom stock (if car exists) or add a placeholder
        if (car != null) {
            car.setQuantity(car.getQuantity() + 1);
        } else {
            // unknown car id: create a placeholder entry
            Car newCar = new Car("UnknownModel", "UnknownBrand", amt, 1, "Unknown");
            showroom.addCar(newCar);
            car = newCar;
        }
        // adjust customer records
        c.removeOwnedCar(cid);
        c.addSpent(-amt);
        // record sellback in sales as special record
        String recId = UUID.randomUUID().toString().substring(0,8);
        String recLine = "SELLBACK | id:" + recId + " | Car:" + car.getName() + "(" + car.getId() + ") | Customer:" + c.getUsername() + " | Paid:" + amt + " | " + new Date();
        FileManager.appendLine("sales.txt", recLine);
        showroom.saveToDisk();
        System.out.println("Sell-back recorded. You received Rs." + amt + ". Invoice appended to sales.txt");
    }

    private static void viewCustomerSales(Customer c) {
        System.out.println("--- Sales involving you ---");
        List<String> lines = FileManager.readLines("sales.txt");
        for (String l : lines) {
            if (l.contains(c.getUsername())) System.out.println(l);
        }
    }

    // ---------------- Guest browsing & search ----------------
    private static void guestBrowse() {
        System.out.println("\n1. List all cars");
        System.out.println("2. Search by name");
        System.out.println("3. Filter by category");
        System.out.println("4. Search by price range");
        System.out.println("5. Sort by price");
        System.out.print("Choose: ");
        String ch = sc.nextLine().trim();
        switch (ch) {
            case "1" -> listCars(showroom.getCars());
            case "2" -> {
                System.out.print("Query: "); String q = sc.nextLine().trim();
                listCars(showroom.searchByName(q));
            }
            case "3" -> {
                System.out.print("Category: "); String cat = sc.nextLine().trim();
                listCars(showroom.getCars().stream().filter(x -> x.getCategory().equalsIgnoreCase(cat)).toList());
            }
            case "4" -> {
                System.out.print("Low: "); int low = readIntOrZero();
                System.out.print("High: "); int high = readIntOrZero();
                listCars(showroom.searchByPriceRange(low, high));
            }
            case "5" -> {
                System.out.print("1. Low->High 2. High->Low : "); String s = sc.nextLine().trim();
                listCars(showroom.sortByPrice(s.equals("1")));
            }
            default -> System.out.println("Invalid");
        }
    }

    // ---------------- Search / Filter helper ----------------
    private static void searchFilterFlow() {
        System.out.println("1. Search by name");
        System.out.println("2. Filter by category");
        System.out.println("3. Sort by name/price/qty");
        System.out.print("Choose: ");
        String choice = sc.nextLine().trim();
        switch (choice) {
            case "1" -> {
                System.out.print("Query: ");
                String q = sc.nextLine().trim();
                listCars(showroom.searchByName(q));
            }
            case "2" -> {
                System.out.print("Category: ");
                String c = sc.nextLine().trim();
                listCars(showroom.getCars().stream().filter(x -> x.getCategory().equalsIgnoreCase(c)).toList());
            }
            case "3" -> {
                System.out.println("1. Name 2. Price Low->High 3. Price High->Low 4. Qty");
                System.out.print("Choose: ");
                String t = sc.nextLine().trim();
                switch (t) {
                    case "1" -> listCars(showroom.sortByName());
                    case "2" -> listCars(showroom.sortByPrice(true));
                    case "3" -> listCars(showroom.sortByPrice(false));
                    case "4" -> listCars(showroom.getCars().stream().sorted(Comparator.comparingInt(Car::getQuantity).reversed()).toList());
                    default -> {
                    }
                }
            }
            default -> {
            }
        }
    }

    // ---------------- Utilities ----------------
    private static void listCars(List<Car> list) {
        if (list == null || list.isEmpty()) {
            System.out.println("No cars to show.");
            return;
        }
        System.out.println("\n--- CARS ---");
        for (Car c : list) System.out.println(c.toString());
    }

    private static int readIntOrZero() {
        String s = sc.nextLine().trim();
        if (s.isEmpty()) return 0;
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) {
            System.out.println("Invalid number, using 0.");
            return 0;
        }
    }
}