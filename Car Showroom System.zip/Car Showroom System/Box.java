/**
 * Generic container (class template / generics example).
 */
public class Box<T> {
    private T value;

    public Box() {}
    public Box(T value) { this.value = value; }

    public void set(T value) { this.value = value; }
    public T get() { return value; }

    public static <E> void printArray(E[] arr) {
        for (E e : arr) System.out.println(e);
    }
}
