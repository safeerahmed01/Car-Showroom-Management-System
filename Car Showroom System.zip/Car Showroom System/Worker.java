import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Worker extends Person — adds soldCount and attendance.
 * Composition: Worker 'has a' list of sale records (optional).
 */
public class Worker extends Person {
    private static final long serialVersionUID = 1L;

    private int soldCount;
    private int attendanceCount;
    private final List<SaleRecord> sales = new ArrayList<>();

    public Worker(String username, String password, String fullName) {
        super(username, password, fullName);
        this.soldCount = 0;
        this.attendanceCount = 0;
    }

    public int getSoldCount() { return soldCount; }
    public void setSoldCount(int soldCount) { this.soldCount = soldCount; }
    public void incrementSold() { soldCount++; }
    // In Worker.java, add this method:
public void setAttendanceCount(int count) {
    this.attendanceCount = count;
}
    public int getAttendanceCount() { return attendanceCount; }
    public void incrementAttendance() { attendanceCount++; }

    public List<SaleRecord> getSales() { return sales; }
    public void recordSale(SaleRecord r) { sales.add(r); incrementSold(); }

    @Override
    public void menu(Scanner sc, Showroom showroom) {
        System.out.println("Worker menu for " + getFullName() + " (override example).");
    }
}
