import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * SaleRecord stores sale metadata (who sold, who bought, price, timestamp).
 */
public class SaleRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String carId;
    private final String carName;
    private final String buyerUsername;
    private final String workerUsername; // may be "N/A" for customer direct
    private final int price;
    private final String timestamp;

    public SaleRecord(String id, String carId, String carName, String buyerUsername, String workerUsername, int price) {
        this.id = id;
        this.carId = carId;
        this.carName = carName;
        this.buyerUsername = buyerUsername;
        this.workerUsername = workerUsername;
        this.price = price;
        this.timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    public String getId() { return id; }
    public String getCarId() { return carId; }
    public String getCarName() { return carName; }
    public String getBuyerUsername() { return buyerUsername; }
    public String getWorkerUsername() { return workerUsername; }
    public int getPrice() { return price; }
    public String getTimestamp() { return timestamp; }

    @Override
    public String toString() {
        return timestamp + " | SaleID:" + id + " | Car:" + carName + "(" + carId + ") | Buyer:" + buyerUsername + " | Worker:" + workerUsername + " | Rs." + price;
    }
}
