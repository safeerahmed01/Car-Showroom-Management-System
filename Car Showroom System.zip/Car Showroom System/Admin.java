import java.util.Scanner;

/**
 * Admin extends Person — inheritance example.
 * Admin overrides menu() to provide admin actions.
 */
public class Admin extends Person {
    private static final long serialVersionUID = 1L;

    // Remove the static defaults or keep them as sample
    public static final String DEFAULT_ADMIN_USER = "admin";
    public static final String DEFAULT_ADMIN_PASS = "admin123";

    // Admin-specific fields can be added here (like permissions level)
    private String adminLevel; // e.g., "Super", "Manager", "Basic"

    public Admin(String username, String password, String fullName) {
        super(username, password, fullName);
        this.adminLevel = "Basic"; // default level
    }
    
    public Admin(String username, String password, String fullName, String adminLevel) {
        super(username, password, fullName);
        this.adminLevel = adminLevel;
    }

    public String getAdminLevel() {
        return adminLevel;
    }

    public void setAdminLevel(String adminLevel) {
        this.adminLevel = adminLevel;
    }

    @Override
    public void menu(Scanner sc, Showroom showroom) {
        // Simple admin menu placeholder
        System.out.println("Admin menu for " + getFullName() + " (Level: " + adminLevel + ")");
    }
    
    @Override
    public String toString() {
        return getUsername() + "," + getPassword() + "," + getFullName() + "," + adminLevel;
    }
}