import java.io.Serializable;
import java.util.Scanner;

/**
 * Abstract Person - demonstrates abstract class and method overriding.
 * Encapsulation: private fields with getters/setters.
 * Polymorphism: concrete subclasses override menu().
 */
public abstract class Person implements Serializable {
    private static final long serialVersionUID = 1L;

    private String username;
    private String password;
    private String fullName;

    public Person(String username, String password, String fullName) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
    }

    // Encapsulation: getters/setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    // Abstract method to be overridden by subclasses (method overriding)
    public abstract void menu(Scanner sc, Showroom showroom);
}
